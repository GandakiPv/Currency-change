package com.example.calculetr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
